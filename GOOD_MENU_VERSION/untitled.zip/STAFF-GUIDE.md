# INYA Cafe Digital Menu - Staff Guide

Welcome to the new digital menu system! This guide will help you manage your cafe's menu items without needing any coding skills.

## How it works
Your website fetches menu items directly from a system called **Sanity CMS**. When you update the menu in Sanity, the changes appear on the live website automatically upon refresh.

## 1. Getting Started
1. Your developer has set up a Sanity project for you. Ask them for your **Sanity Studio URL** (e.g., `https://inya-cafe-menu.sanity.studio`).
2. Go to that URL and log in using the email invite you received.
3. Once logged in, you will see a clean dashboard with two main sections on the left:
   - **Menu Categories** (e.g., Breakfast, Bagels, Salads)
   - **Menu Items** (The individual dishes and drinks)

## 2. Managing Categories
Categories group your menu items (like "Specialty Coffees" or "Dessert").
- **To add a category:** Click on "Menu Category", then the "+" or "Create" button. Give it a title, generate a slug, and set a sort order (e.g., 1 for Breakfast, 2 for Bagels).
- **To edit a category:** Click an existing category and change its name.

## 3. Adding or Editing a Menu Item
- **To add an item:** Click on "Menu Item", then create a new one.
- **To edit an item:** Click on any existing item in the list.

### Key Fields to Fill Out:
- **Name:** The name of the dish (e.g., "Vietnamese Iced Coffee").
- **Category:** Select a category from the dropdown (you must create categories first).
- **Price (₹):** Enter the number without the currency symbol (e.g., `215`).
- **Description:** A short, warm description of the dish.
- **Dietary Type:** Veg, Egg, or Non-Veg. This controls the green/brown icons on the website.
- **Tags:** Add tags like `bestseller`, `chefs-special`, or `new`. These show up as cute little pills on the menu card.
- **Main Image:** Click to upload a food photo. (Images look best when they are relatively square or 4:3 landscape).
- **Is Available:** If you run out of an item, simply toggle this switch OFF. It will instantly hide from the website without deleting it. Toggle it back ON when you restock!

## 4. Publishing Changes
When you make a change, it saves automatically as a "Draft".
To make the change live on the website, look for the big green **Publish** button at the bottom right. Click it, and your customers will see the updated menu!
