import { loadPartials } from './partials.js';

async function init() {
  await loadPartials();
  
  const header = document.querySelector("[data-header]");
  const progress = document.querySelector("[data-progress]");
  const menuToggle = document.querySelector("[data-menu-toggle]");
  const navLinks = document.querySelectorAll(".nav-links a");
  const navSections = [...navLinks].map((link) => {
    try {
      const url = new URL(link.href, window.location.origin);
      if (url.pathname === window.location.pathname && url.hash) {
        return document.querySelector(url.hash);
      }
    } catch (e) {}
    return null;
  }).filter(Boolean);

  function setMenuOpen(isOpen) {
    if (!header) return;
    header.classList.toggle("is-menu-open", isOpen);
    if(menuToggle) {
      menuToggle.setAttribute("aria-expanded", String(isOpen));
      menuToggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
    }
  }

  function updateHeader() {
    if (!header) return;
    header.classList.toggle("is-scrolled", window.scrollY > 24);
    
    if (progress) {
      const scrollable = document.documentElement.scrollHeight - window.innerHeight;
      const scrolled = scrollable > 0 ? window.scrollY / scrollable : 0;
      progress.style.transform = `scaleX(${Math.min(Math.max(scrolled, 0), 1)})`;
    }

    if (window.location.pathname === '/' || window.location.pathname === '/index.html' || window.location.pathname === '') {
      const activeSection = navSections
        .filter((section) => section && section.getBoundingClientRect().top <= 130)
        .pop();

      navLinks.forEach((link) => {
        if (link.getAttribute("href").startsWith("/#") || link.getAttribute("href").startsWith("#")) {
           link.classList.toggle("is-active", activeSection && link.href.endsWith(`#${activeSection.id}`));
        }
      });
    }
  }

  updateHeader();
  window.addEventListener("scroll", updateHeader, { passive: true });

  if (menuToggle) {
    menuToggle.addEventListener("click", () => {
      setMenuOpen(!header.classList.contains("is-menu-open"));
    });
  }

  navLinks.forEach((link) => {
    link.addEventListener("click", () => setMenuOpen(false));
  });

  window.addEventListener("resize", () => {
    if (window.innerWidth > 860) {
      setMenuOpen(false);
    }
  });

  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      setMenuOpen(false);
    }
  });

  // Reveal logic
  const revealItems = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.14 });

    revealItems.forEach((item) => observer.observe(item));
  } else {
    revealItems.forEach((item) => item.classList.add("is-visible"));
  }

  // Carousel Arrows
  const menuCarousel = document.getElementById('menuCarousel');
  const leftArrow = document.querySelector('.left-arrow');
  const rightArrow = document.querySelector('.right-arrow');

  if (menuCarousel && leftArrow && rightArrow) {
    leftArrow.addEventListener('click', () => {
      const scrollAmount = menuCarousel.clientWidth * 0.8;
      menuCarousel.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    });

    rightArrow.addEventListener('click', () => {
      const scrollAmount = menuCarousel.clientWidth * 0.8;
      menuCarousel.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    });
  }
}

document.addEventListener('DOMContentLoaded', init);
