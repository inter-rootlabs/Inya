import { fetchMenuItems } from './sanity-client.js';
import { ENABLE_CART_HOOKS } from './config.js';

let allItems = [];
let filteredItems = [];
let categories = [];
let activeItemIndex = -1;

const state = {
  search: '',
  diet: 'all', // all, veg, egg, non-veg
  sort: 'recommended', // recommended, rating, price-asc, price-desc
  quickFilters: {
    'rated-4': false,
    'bestseller': false,
    'chefs-special': false,
    'new': false
  }
};

const dom = {
  searchInput: document.getElementById('searchInput'),
  dietBtns: document.querySelectorAll('.segmented-btn'),
  sortSelect: document.getElementById('sortSelect'),
  quickChips: document.querySelectorAll('.quick-filters .chip'),
  grid: document.getElementById('menuGrid'),
  categoryNav: document.getElementById('categoryNavInner'),
  
  // Modal
  modalOverlay: document.getElementById('itemModal'),
  modalClose: document.getElementById('modalClose'),
  modalMedia: document.getElementById('modalMedia'),
  modalTitle: document.getElementById('modalTitle'),
  modalPrice: document.getElementById('modalPrice'),
  modalDesc: document.getElementById('modalDesc'),
  modalTags: document.getElementById('modalTags'),
  modalMeta: document.getElementById('modalMeta'),
  btnPrev: document.getElementById('modalPrev'),
  btnNext: document.getElementById('modalNext'),
  addBtnArea: document.getElementById('modalAddArea')
};

async function init() {
  try {
    allItems = await fetchMenuItems();
    // Group categories
    const catMap = new Map();
    allItems.forEach(item => {
      if(!catMap.has(item.category)) {
        catMap.set(item.category, { name: item.category, slug: item.categorySlug, items: [] });
      }
      catMap.get(item.category).items.push(item);
    });
    categories = Array.from(catMap.values());
    
    renderCategoryNav();
    applyFilters();
    setupEventListeners();
    setupScrollSpy();
  } catch (error) {
    console.error("Error initializing menu:", error);
    dom.grid.innerHTML = `<div class="empty-state"><p>Failed to load menu. Please try again later.</p></div>`;
  }
}

function renderCategoryNav() {
  dom.categoryNav.innerHTML = categories.map(cat => 
    `<a href="#cat-${cat.slug}" class="cat-link" data-cat="${cat.slug}">${cat.name}</a>`
  ).join('');
}

function setupEventListeners() {
  let debounceTimeout;
  dom.searchInput.addEventListener('input', (e) => {
    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(() => {
      state.search = e.target.value.toLowerCase();
      applyFilters();
    }, 200);
  });

  dom.dietBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      dom.dietBtns.forEach(b => b.setAttribute('aria-pressed', 'false'));
      btn.setAttribute('aria-pressed', 'true');
      state.diet = btn.dataset.diet;
      applyFilters();
    });
  });

  dom.sortSelect.addEventListener('change', (e) => {
    state.sort = e.target.value;
    applyFilters();
  });

  dom.quickChips.forEach(chip => {
    chip.addEventListener('click', () => {
      const filter = chip.dataset.filter;
      const isActive = chip.getAttribute('aria-pressed') === 'true';
      chip.setAttribute('aria-pressed', !isActive ? 'true' : 'false');
      state.quickFilters[filter] = !isActive;
      applyFilters();
    });
  });

  dom.modalClose.addEventListener('click', closeModal);
  dom.modalOverlay.addEventListener('click', (e) => {
    if(e.target === dom.modalOverlay) closeModal();
  });
  window.addEventListener('keydown', (e) => {
    if(e.key === 'Escape' && dom.modalOverlay.classList.contains('is-active')) closeModal();
  });

  dom.btnPrev.addEventListener('click', () => navigateModal(-1));
  dom.btnNext.addEventListener('click', () => navigateModal(1));
  
  // Clear filters delegation
  dom.grid.addEventListener('click', (e) => {
    if(e.target.id === 'clearFiltersBtn') {
      state.search = '';
      dom.searchInput.value = '';
      state.diet = 'all';
      dom.dietBtns.forEach(b => b.setAttribute('aria-pressed', b.dataset.diet === 'all' ? 'true' : 'false'));
      Object.keys(state.quickFilters).forEach(k => state.quickFilters[k] = false);
      dom.quickChips.forEach(c => c.setAttribute('aria-pressed', 'false'));
      applyFilters();
    }
  });
}

function applyFilters() {
  filteredItems = allItems.filter(item => {
    // Diet
    if (state.diet !== 'all' && item.dietaryType !== state.diet) return false;
    
    // Quick filters (AND logic)
    if (state.quickFilters['rated-4'] && (!item.rating || item.rating.average < 4)) return false;
    if (state.quickFilters['bestseller'] && !item.tags?.includes('bestseller')) return false;
    if (state.quickFilters['chefs-special'] && !item.tags?.includes('chefs-special')) return false;
    if (state.quickFilters['new'] && !item.tags?.includes('new')) return false;

    // Search
    if (state.search) {
      const searchStr = `${item.name} ${item.description || ''} ${item.tags?.join(' ')}`.toLowerCase();
      if (!searchStr.includes(state.search)) return false;
    }
    return true;
  });

  // Sort
  filteredItems.sort((a, b) => {
    if (state.sort === 'rating') {
      const aR = a.rating?.average || 0;
      const bR = b.rating?.average || 0;
      return bR - aR;
    } else if (state.sort === 'price-asc') {
      return a.price - b.price;
    } else if (state.sort === 'price-desc') {
      return b.price - a.price;
    }
    // Recommended keeps existing order (fetched sorted by category + sortOrder)
    return 0;
  });

  renderGrid();
}

function renderGrid() {
  if (filteredItems.length === 0) {
    dom.grid.innerHTML = `
      <div class="empty-state">
        <h3>No matches found</h3>
        <p>We couldn't find anything matching your current filters.</p>
        <button id="clearFiltersBtn" class="button secondary">Clear all filters</button>
      </div>`;
    return;
  }

  // If sorting by recommended, group by category
  if (state.sort === 'recommended') {
    const cats = {};
    filteredItems.forEach(item => {
      if(!cats[item.categorySlug]) cats[item.categorySlug] = { name: item.category, items: [] };
      cats[item.categorySlug].items.push(item);
    });

    let html = '';
    for (const [slug, cat] of Object.entries(cats)) {
      html += `
        <div class="menu-section" id="cat-${slug}">
          <h2 class="menu-section-title">${cat.name}</h2>
          <div class="grid-container">
            ${cat.items.map(item => generateCardHtml(item)).join('')}
          </div>
        </div>
      `;
    }
    dom.grid.innerHTML = html;
  } else {
    // Flat list for other sorts
    dom.grid.innerHTML = `
      <div class="menu-section">
        <div class="grid-container">
          ${filteredItems.map(item => generateCardHtml(item)).join('')}
        </div>
      </div>
    `;
  }

  // Bind click events to cards
  document.querySelectorAll('.menu-card').forEach(card => {
    card.addEventListener('click', (e) => {
      // Don't trigger if they clicked the add button directly
      if(e.target.closest('.card-add-btn')) return; 
      const id = card.dataset.id;
      const index = filteredItems.findIndex(i => i._id === id);
      if(index !== -1) openModal(index);
    });
  });
  
  if (ENABLE_CART_HOOKS) {
    document.querySelectorAll('.card-add-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.currentTarget.dataset.id;
        console.log(`Add to cart clicked for item: ${id}`);
        // Integration hook goes here later
      });
    });
  }
}

function generateCardHtml(item) {
  const badgeClass = item.dietaryType === 'non-veg' ? 'non-veg' : (item.dietaryType === 'egg' ? 'egg' : 'veg');
  const ratingHtml = item.rating?.average ? 
    `<div class="card-rating">
      <svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path></svg>
      ${item.rating.average} (${item.rating.count || 0})
    </div>` : '';
    
  const tagsHtml = item.tags && item.tags.length > 0 ? 
    `<div class="card-tags">
      ${item.tags.map(tag => `<span class="card-tag">${tag.replace('-', ' ')}</span>`).join('')}
    </div>` : '';
    
  const addBtnHtml = ENABLE_CART_HOOKS ? 
    `<button class="card-add-btn" data-id="${item._id}" aria-label="Add to order">
      <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
    </button>` : '';

  return `
    <article class="menu-card" data-id="${item._id}">
      <div class="menu-card-image">
        <div class="diet-badge ${badgeClass}" title="${item.dietaryType}"></div>
        ${tagsHtml}
        <img src="${item.imageUrl || ''}" alt="${item.imageAlt || item.name}" loading="lazy">
        ${addBtnHtml}
      </div>
      <div class="menu-card-content">
        <div class="card-header">
          <h3>${item.name}</h3>
          <span class="card-price">₹${item.price}</span>
        </div>
        ${ratingHtml}
        <p class="card-desc">${item.description || ''}</p>
      </div>
    </article>
  `;
}

function openModal(index) {
  activeItemIndex = index;
  updateModalContent();
  dom.modalOverlay.classList.add('is-active');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  dom.modalOverlay.classList.remove('is-active');
  document.body.style.overflow = '';
}

function navigateModal(direction) {
  const newIndex = activeItemIndex + direction;
  if (newIndex >= 0 && newIndex < filteredItems.length) {
    activeItemIndex = newIndex;
    updateModalContent();
  }
}

function updateModalContent() {
  const item = filteredItems[activeItemIndex];
  if (!item) return;

  dom.btnPrev.disabled = activeItemIndex === 0;
  dom.btnNext.disabled = activeItemIndex === filteredItems.length - 1;

  if (item.videoUrl) {
    dom.modalMedia.innerHTML = `<video src="${item.videoUrl}" autoplay muted loop playsinline poster="${item.imageUrl}"></video>`;
  } else {
    dom.modalMedia.innerHTML = `<img src="${item.imageUrl}" alt="${item.name}">`;
  }

  dom.modalTitle.textContent = item.name;
  dom.modalPrice.textContent = `₹${item.price}`;
  dom.modalDesc.textContent = item.description || '';

  const badgeClass = item.dietaryType === 'non-veg' ? 'non-veg' : (item.dietaryType === 'egg' ? 'egg' : 'veg');
  const typeLabel = item.dietaryType.charAt(0).toUpperCase() + item.dietaryType.slice(1);
  
  let metaHtml = `
    <div class="meta-item">
      <div class="diet-badge ${badgeClass}" style="position:static; margin-right:4px;"></div>
      ${typeLabel}
    </div>
  `;

  if (item.prepTimeMinutes) {
    metaHtml += `
      <div class="meta-item">
        <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
        ~${item.prepTimeMinutes} min
      </div>
    `;
  }

  if (item.spiceLevel && item.spiceLevel !== 'none') {
    metaHtml += `
      <div class="meta-item">
        <svg viewBox="0 0 24 24" fill="none"><path d="M12 2C8 6 6 10 6 14c0 3.3 2.7 6 6 6s6-2.7 6-6c0-4-2-8-6-12z" fill="#c62828"/></svg>
        ${item.spiceLevel}
      </div>
    `;
  }
  
  if (item.rating?.average) {
    metaHtml += `
      <div class="meta-item card-rating" style="margin:0;">
        <svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path></svg>
        ${item.rating.average} (${item.rating.count || 0} reviews)
      </div>
    `;
  }

  dom.modalMeta.innerHTML = metaHtml;
  
  if (item.tags && item.tags.length > 0) {
    dom.modalTags.innerHTML = item.tags.map(tag => `<span class="chip" style="font-size:0.75rem; min-height:auto; padding:4px 10px;">${tag.replace('-', ' ')}</span>`).join('');
  } else {
    dom.modalTags.innerHTML = '';
  }
  
  if (ENABLE_CART_HOOKS) {
    dom.addBtnArea.innerHTML = `<button class="button primary add-to-cart-large" onclick="console.log('Add ${item._id}')">Add to Order — ₹${item.price}</button>`;
  } else {
    dom.addBtnArea.innerHTML = '';
  }
}

function setupScrollSpy() {
  const observer = new IntersectionObserver((entries) => {
    // When sorting isn't recommended, sections don't exist in the same way
    if (state.sort !== 'recommended') return;
    
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.id;
        document.querySelectorAll('.cat-link').forEach(link => {
          link.classList.toggle('is-active', link.getAttribute('href') === `#${id}`);
        });
        
        // Ensure nav scrolls to show active item
        const activeLink = document.querySelector(`.cat-link[href="#${id}"]`);
        if (activeLink && dom.categoryNav) {
          activeLink.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        }
      }
    });
  }, { rootMargin: '-200px 0px -60% 0px' });

  // Disconnect old, observe new
  const observeSections = () => {
    observer.disconnect();
    document.querySelectorAll('.menu-section').forEach(section => observer.observe(section));
  };
  
  // Re-run whenever grid changes
  const mutationObserver = new MutationObserver(observeSections);
  mutationObserver.observe(dom.grid, { childList: true });
}

document.addEventListener('DOMContentLoaded', init);
