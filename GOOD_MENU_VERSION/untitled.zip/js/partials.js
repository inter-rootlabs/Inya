export async function loadPartials() {
  try {
    const [headerRes, footerRes] = await Promise.all([
      fetch('./partials/header.html'),
      fetch('./partials/footer.html')
    ]);
    
    if (headerRes.ok) {
      document.getElementById('site-header').innerHTML = await headerRes.text();
    }
    if (footerRes.ok) {
      document.getElementById('site-footer').innerHTML = await footerRes.text();
    }

    // Highlight active link if on menu page
    if (window.location.pathname.includes('menu.html')) {
      const menuLink = document.querySelector('.nav-links a[href="menu.html"], .nav-links a[href="/menu.html"]');
      if (menuLink) menuLink.classList.add('is-active');
    }
  } catch (error) {
    console.error('Error loading partials:', error);
  }
}
