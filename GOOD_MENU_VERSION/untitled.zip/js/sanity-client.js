const PROJECT_ID = 'your-project-id'; // Replace with real ID
const DATASET = 'production';
const API_VERSION = 'v2024-08-01';

export async function fetchMenuItems() {
  const query = encodeURIComponent(`*[_type == "menuItem" && isAvailable == true] | order(category->sortOrder asc, sortOrder asc) {
    _id, name, "slug": slug.current, price, description, prepTimeMinutes,
    dietaryType, spiceLevel, tags, rating, curatedTestimonials, videoUrl,
    "category": category->title,
    "categorySlug": category->slug.current,
    "imageUrl": mainImage.asset->url,
    "imageAlt": name
  }`);
  const url = `https://${PROJECT_ID}.api.sanity.io/${API_VERSION}/data/query/${DATASET}?query=${query}`;
  
  // For the sake of the static preview without a running Sanity backend,
  // we will fallback to our local menu_data.json if Sanity fetch fails.
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error('Sanity fetch failed');
    const { result } = await res.json();
    return result;
  } catch (error) {
    console.warn("Using fallback local data since Sanity is not configured yet.");
    const fallbackRes = await fetch('./scripts/menu_data.json');
    const localData = await fallbackRes.json();
    return localData.map((item, idx) => ({
      _id: `local-${idx}`,
      name: item.name,
      price: item.price,
      description: item.description,
      dietaryType: item.dietaryType,
      prepTimeMinutes: item.prepTimeMinutes,
      tags: item.tags || [],
      category: item.category,
      categorySlug: item.category.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      imageUrl: `https://picsum.photos/seed/${item.name.replace(/[^a-zA-Z]/g, '')}/800/600`,
      imageAlt: item.name
    }));
  }
}
