const { createClient } = require('@sanity/client');
const fs = require('fs');
const path = require('path');
const https = require('https');

// Initialize the Sanity client
// REPLACE THESE WITH YOUR ACTUAL SANITY PROJECT DETAILS BEFORE RUNNING
const client = createClient({
  projectId: process.env.SANITY_PROJECT_ID || 'your-project-id',
  dataset: process.env.SANITY_DATASET || 'production',
  useCdn: false,
  apiVersion: '2024-08-01',
  token: process.env.SANITY_API_TOKEN || 'your-write-token' // Needs a token with write permissions
});

// Helper to fetch an image buffer from a URL (e.g. Picsum or Pexels)
function fetchImageBuffer(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      const data = [];
      res.on('data', (chunk) => data.push(chunk));
      res.on('end', () => resolve(Buffer.concat(data)));
    }).on('error', reject);
  });
}

// Convert string to slug
function slugify(text) {
  return text.toString().toLowerCase()
    .replace(/\s+/g, '-')           // Replace spaces with -
    .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
    .replace(/\-\-+/g, '-')         // Replace multiple - with single -
    .replace(/^-+/, '')             // Trim - from start of text
    .replace(/-+$/, '');            // Trim - from end of text
}

async function seed() {
  console.log('Starting seed process...');
  
  // 1. Read the extracted menu data
  const dataPath = path.join(__dirname, 'menu_data.json');
  const rawData = fs.readFileSync(dataPath, 'utf8');
  const menuItems = JSON.parse(rawData);
  
  // 2. Extract unique categories and create them
  const categoryNames = [...new Set(menuItems.map(item => item.category))];
  const categoryMap = {}; // Maps category name to Sanity Document ID
  
  console.log(`Found ${categoryNames.length} categories. Creating...`);
  
  for (let i = 0; i < categoryNames.length; i++) {
    const name = categoryNames[i];
    const categoryDoc = {
      _type: 'category',
      title: name,
      slug: { _type: 'slug', current: slugify(name) },
      sortOrder: i + 1
    };
    
    const created = await client.create(categoryDoc);
    categoryMap[name] = created._id;
    console.log(`Created category: ${name}`);
  }
  
  // 3. Process and create menu items
  console.log(`Creating ${menuItems.length} menu items...`);
  
  for (let i = 0; i < menuItems.length; i++) {
    const item = menuItems[i];
    
    // Fetch a placeholder stock image based on the item name using Picsum for seed purposes
    // (In a real scenario, you could use Pexels API here)
    const seedId = slugify(item.name) || i;
    const imageUrl = `https://picsum.photos/seed/${seedId}/800/600`;
    
    console.log(`Uploading image for: ${item.name}...`);
    let imageAsset;
    try {
      const imageBuffer = await fetchImageBuffer(imageUrl);
      imageAsset = await client.assets.upload('image', imageBuffer, {
        filename: `${slugify(item.name)}.jpg`
      });
    } catch (e) {
      console.error(`Failed to upload image for ${item.name}, skipping image...`, e);
    }
    
    const itemDoc = {
      _type: 'menuItem',
      name: item.name,
      slug: { _type: 'slug', current: slugify(item.name) },
      category: {
        _type: 'reference',
        _ref: categoryMap[item.category]
      },
      price: item.price,
      description: item.description,
      dietaryType: item.dietaryType,
      prepTimeMinutes: item.prepTimeMinutes,
      tags: item.tags,
      isAvailable: true,
      sortOrder: i + 1,
    };
    
    if (imageAsset) {
      itemDoc.mainImage = {
        _type: 'image',
        asset: {
          _type: 'reference',
          _ref: imageAsset._id
        }
      };
    }
    
    await client.create(itemDoc);
    console.log(`Created item: ${item.name}`);
  }
  
  console.log('Seed complete!');
}

seed().catch(err => {
  console.error('Seed failed:', err);
});
