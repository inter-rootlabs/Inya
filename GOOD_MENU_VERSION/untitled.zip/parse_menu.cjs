const fs = require('fs');

const menuData = JSON.parse(fs.readFileSync('scripts/menu_data.json', 'utf8'));

menuData.forEach((item, index) => {
  // Add some random ratings to ~60% of items
  if (Math.random() > 0.4) {
    item.rating = {
      average: (4.0 + Math.random()).toFixed(1),
      count: Math.floor(Math.random() * 120) + 5
    };
  }
  
  // Add some tags
  item.tags = [];
  if (Math.random() > 0.8) item.tags.push('bestseller');
  if (Math.random() > 0.9) item.tags.push('chefs-special');
  if (Math.random() > 0.9) item.tags.push('new');
  
  if (item.category === 'Specialty Coffees' || item.category === 'Sandwiches') {
    item.tags.push('chefs-special');
  }
  
  // Add spice levels occasionally
  if (item.category === 'Turkish Pide' || item.category === 'Sandwiches') {
    item.spiceLevel = ['none', 'mild', 'medium', 'hot'][Math.floor(Math.random() * 4)];
  }
});

fs.writeFileSync('scripts/menu_data.json', JSON.stringify(menuData, null, 2));
console.log('Updated menu_data.json with random ratings and tags');
