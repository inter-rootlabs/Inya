export default {
  name: 'category',
  title: 'Menu Category',
  type: 'document',
  fields: [
    { name: 'title', type: 'string', validation: (Rule) => Rule.required() },
    { name: 'slug', type: 'slug', options: { source: 'title' } },
    { name: 'sortOrder', type: 'number', initialValue: 0 },
  ],
}
