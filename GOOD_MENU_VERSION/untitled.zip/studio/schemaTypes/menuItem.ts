export default {
  name: 'menuItem',
  title: 'Menu Item',
  type: 'document',
  fields: [
    { name: 'name', type: 'string', validation: (Rule) => Rule.required() },
    { name: 'slug', type: 'slug', options: { source: 'name' } },
    { name: 'category', type: 'reference', to: [{ type: 'category' }], validation: (Rule) => Rule.required() },
    { name: 'price', title: 'Price (₹)', type: 'number', validation: (Rule) => Rule.required().positive() },
    { name: 'description', type: 'text', rows: 3 },
    { name: 'prepTimeMinutes', title: 'Approx. prep time (minutes)', type: 'number' },
    {
      name: 'dietaryType',
      type: 'string',
      options: { list: [
        { title: 'Veg', value: 'veg' },
        { title: 'Egg', value: 'egg' },
        { title: 'Non-Veg', value: 'non-veg' },
      ] },
      validation: (Rule) => Rule.required(),
    },
    { name: 'spiceLevel', type: 'string', options: { list: ['none', 'mild', 'medium', 'hot'] } },
    {
      name: 'tags',
      type: 'array',
      of: [{ type: 'string' }],
      options: { list: ['bestseller', 'chefs-special', 'new'] },
    },
    { name: 'mainImage', type: 'image', options: { hotspot: true }, validation: (Rule) => Rule.required() },
    { name: 'gallery', type: 'array', of: [{ type: 'image', options: { hotspot: true } }] },
    { name: 'videoUrl', title: 'Video (optional)', type: 'url' },
    {
      name: 'rating',
      type: 'object',
      fields: [
        { name: 'average', type: 'number' },
        { name: 'count', type: 'number' },
      ],
    },
    {
      name: 'curatedTestimonials',
      title: "Curated customer quotes",
      type: 'array',
      of: [{ type: 'object', fields: [
        { name: 'quote', type: 'string' },
        { name: 'author', type: 'string' },
      ] }],
    },
    { name: 'isAvailable', type: 'boolean', initialValue: true },
    { name: 'sortOrder', type: 'number', initialValue: 0 },
  ],
}
